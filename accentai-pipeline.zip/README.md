# AccentAI: Deep Learning Accent Classification

A modular and robust Python pipeline for English accent classification from audio recordings using Log-Mel Spectrograms and a CNN-based classifier.

## Project Structure

```bash
project/
├── data/
│   ├── raw/           # WAV/MP3 files
│   └── metadata.csv   # Filename, label mapping
├── configs/
│   └── config.yaml    # All hyperparameters and paths
├── src/
│   ├── preprocessing/ # Audio cleaning & feature extraction
│   ├── datasets/      # PyTorch Dataset implementation
│   ├── models/        # CNN architecture
│   ├── training/      # Training loop & logic
│   ├── evaluation/    # Metrics and plotting
│   └── utils/         # Reproducibility and device helpers
├── checkpoints/       # Saved models
├── outputs/           # Logs, labels, and plots
├── requirements.txt
├── train.py           # Training entry point
└── predict.py         # Inference script
```

## Setup

1.  **Environment**: Python 3.11+ is recommended.
2.  **Dependencies**:
    ```bash
    pip install -r requirements.txt
    ```

## Usage

### 1. Prepare Data
Ensure your `metadata.csv` follows this format:
```csv
filename,label
audio_001.wav,british
audio_002.wav,american
```
Place audio files in `data/raw/`.

### 2. Training
Adjust hyperparameters in `configs/config.yaml`, then run:
```bash
python train.py
```
This will:
*   Perform train/val/test splits.
*   Train the CNN with early stopping.
*   Save the best model to `checkpoints/`.
*   Generate a confusion matrix and report in `outputs/`.

### 3. Inference
Predict the accent of a single file:
```bash
python predict.py --input path/to/audio.wav
```
Or a whole folder:
```bash
python predict.py --input data/samples/
```

## Engineering Highlights
*   **Audio Pipeline**: Resampling (16kHz), Mono conversion, Silence trimming, and Log-Mel Spectrogram extraction.
*   **Reproducibility**: Global seeding for PyTorch, NumPy, and Python Random.
*   **Augmentation**: SpecAugment (Time/Frequency masking) and Gaussian noise applied during training.
*   **Clean CNN**: A readable architecture with Conv blocks, GAP, and Dropout.
*   **Monitoring**: Progress bars with `tqdm`, loss tracking, and mixed precision ready.
