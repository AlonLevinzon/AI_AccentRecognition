import yaml
import torch
import pandas as pd
from sklearn.model_selection import train_test_split
from torch.utils.data import DataLoader
import os

from src.utils.reproducibility import set_seed, get_device
from src.datasets.accent_dataset import AccentDataset
from src.models.cnn import AccentClassifier
from src.training.trainer import Trainer
from src.evaluation.metrics import evaluate_model

def main():
    # 1. Load Config
    with open('configs/config.yaml', 'r') as f:
        config = yaml.safe_load(f)
        
    set_seed(config['training']['seed'])
    device = get_device()
    
    # 2. Setup Directories
    os.makedirs(config['paths']['checkpoints_dir'], exist_ok=True)
    os.makedirs(config['paths']['outputs_dir'], exist_ok=True)
    
    # 3. Load Metadata
    metadata_path = config['paths']['metadata_csv']
    if not os.path.exists(metadata_path):
        print(f"Error: {metadata_path} not found. Please provide data first.")
        return
        
    df = pd.read_csv(metadata_path)
    
    # Label Encoding
    unique_labels = sorted(df['label'].unique())
    label_encoder = {label: i for i, label in enumerate(unique_labels)}
    label_encoder_inv = {i: label for label, i in label_encoder.items()}
    
    # Save label encoder for prediction
    with open(os.path.join(config['paths']['outputs_dir'], 'labels.yaml'), 'w') as f:
        yaml.dump(label_encoder_inv, f)
    
    # 4. Splits
    train_df, temp_df = train_test_split(df, test_size=0.3, stratify=df['label'], random_state=42)
    val_df, test_df = train_test_split(temp_df, test_size=0.5, stratify=temp_df['label'], random_state=42)
    
    # 5. DataLoaders
    train_ds = AccentDataset(train_df, config['paths']['audio_dir'], config, label_encoder, is_training=True)
    val_ds = AccentDataset(val_df, config['paths']['audio_dir'], config, label_encoder, is_training=False)
    test_ds = AccentDataset(test_df, config['paths']['audio_dir'], config, label_encoder, is_training=False)
    
    train_loader = DataLoader(train_ds, batch_size=config['training']['batch_size'], shuffle=True, num_workers=4, pin_memory=True)
    val_loader = DataLoader(val_ds, batch_size=config['training']['batch_size'], shuffle=False, num_workers=4, pin_memory=True)
    test_loader = DataLoader(test_ds, batch_size=config['training']['batch_size'], shuffle=False, num_workers=4, pin_memory=True)
    
    # 6. Model & Trainer
    model = AccentClassifier(num_classes=len(unique_labels), config=config)
    trainer = Trainer(model, train_loader, val_loader, config, device)
    
    # 7. Start Training
    trainer.fit()
    
    # 8. Evaluation
    print("\nRunning test evaluation...")
    best_model_path = os.path.join(config['paths']['checkpoints_dir'], 'best_model.pth')
    checkpoint = torch.load(best_model_path, map_location=device)
    model.load_state_dict(checkpoint['model_state_dict'])
    
    evaluate_model(model, test_loader, device, label_encoder_inv, config['paths']['outputs_dir'])

if __name__ == "__main__":
    main()
