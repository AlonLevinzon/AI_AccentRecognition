import pandas as pd
import torch
from torch.utils.data import Dataset
import os
import torchaudio.transforms as T
from src.preprocessing.audio import AudioPreprocessor

class AccentDataset(Dataset):
    def __init__(self, metadata_df, audio_dir, config, label_encoder, transform=None, is_training=False):
        self.df = metadata_df
        self.audio_dir = audio_dir
        self.config = config
        self.preprocessor = AudioPreprocessor(config)
        self.label_encoder = label_encoder
        self.is_training = is_training
        
        # Augmentations
        self.time_mask = T.TimeMasking(time_mask_param=config['augmentation']['time_mask_param'])
        self.freq_mask = T.FrequencyMasking(freq_mask_param=config['augmentation']['freq_mask_param'])

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        audio_path = os.path.join(self.audio_dir, row['filename'])
        label_str = row['label']
        label = self.label_encoder[label_str]
        
        try:
            # 1. Load and basic preprocess
            waveform = self.preprocessor.load_audio(audio_path)
            
            # 2. Random cropping for training if longer than target
            if self.is_training:
                target_len = self.preprocessor.target_samples
                if waveform.shape[1] > target_len:
                    start_idx = torch.randint(0, waveform.shape[1] - target_len, (1,)).item()
                    waveform = waveform[:, start_idx:start_idx + target_len]
            
            waveform = self.preprocessor.preprocess(waveform)
            
            # 3. Feature Extraction
            features = self.preprocessor.extract_features(waveform)
            
            # 4. Augmentations (Only during training)
            if self.is_training and self.config['augmentation']['enabled']:
                features = self.time_mask(features)
                features = self.freq_mask(features)
                if torch.rand(1).item() < 0.5:
                    noise = torch.randn_like(features) * self.config['augmentation']['noise_std']
                    features = features + noise
            
            return features, torch.tensor(label, dtype=torch.long)
            
        except Exception as e:
            print(f"Error processing {audio_path}: {e}")
            # Return a zero tensor if file fails (ideally handle this better in production)
            return torch.zeros((1, self.config['audio']['n_mels'], 501)), torch.tensor(0)
