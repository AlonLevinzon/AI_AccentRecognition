import torch
import torchaudio
import torchaudio.transforms as T
import librosa
import numpy as np

class AudioPreprocessor:
    def __init__(self, config):
        self.sr = config['audio']['sample_rate']
        self.duration = config['audio']['duration']
        self.target_samples = int(self.sr * self.duration)
        
        # Spectrogram transforms
        self.mel_spec = T.MelSpectrogram(
            sample_rate=self.sr,
            n_mels=config['audio']['n_mels'],
            n_fft=config['audio']['n_fft'],
            hop_length=config['audio']['hop_length'],
            win_length=config['audio']['win_length']
        )
        self.amplitude_to_db = T.AmplitudeToDB()
        
        # Low-pass frequency
        self.low_pass_freq = config['audio']['low_pass_freq']

    def load_audio(self, path):
        # Load audio using torchaudio
        waveform, sr = torchaudio.load(path)
        
        # 1. Resample if necessary
        if sr != self.sr:
            resampler = T.Resample(sr, self.sr)
            waveform = resampler(waveform)
            
        # 2. Convert to mono if stereo
        if waveform.shape[0] > 1:
            waveform = torch.mean(waveform, dim=0, keepdim=True)
            
        return waveform

    def preprocess(self, waveform):
        # 3. Silence Trimming (using librosa via numpy conversion)
        y = waveform.squeeze().numpy()
        y_trimmed, _ = librosa.effects.trim(y)
        waveform = torch.from_numpy(y_trimmed).unsqueeze(0)
        
        # 4. Loudness Normalization
        if waveform.abs().max() > 0:
            waveform = waveform / waveform.abs().max()
            
        # 5. Fixed-Length (Pad or Truncate)
        if waveform.shape[1] > self.target_samples:
            # Simple truncation for now; random cropping done in Dataset
            waveform = waveform[:, :self.target_samples]
        elif waveform.shape[1] < self.target_samples:
            padding = self.target_samples - waveform.shape[1]
            waveform = torch.nn.functional.pad(waveform, (0, padding))
            
        return waveform

    def extract_features(self, waveform):
        # 6. Log-Mel Spectrogram
        mel_spectrogram = self.mel_spec(waveform)
        log_mel_spectrogram = self.amplitude_to_db(mel_spectrogram)
        
        # Per-sample normalization (StandardScaler style)
        mean = log_mel_spectrogram.mean()
        std = log_mel_spectrogram.std()
        log_mel_spectrogram = (log_mel_spectrogram - mean) / (std + 1e-6)
        
        return log_mel_spectrogram
