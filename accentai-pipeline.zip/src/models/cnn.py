import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvBlock(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1, padding=1):
        super().__init__()
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU()
        self.pool = nn.MaxPool2d(2)

    def forward(self, x):
        return self.pool(self.relu(self.bn(self.conv(x))))

class AccentClassifier(nn.Module):
    def __init__(self, num_classes, config):
        super().__init__()
        base_filters = config['model']['base_filters']
        dropout = config['model']['dropout_rate']
        
        # input: (1, n_mels=128, time_steps)
        self.layer1 = ConvBlock(1, base_filters)         # Output: (32, 64, T/2)
        self.layer2 = ConvBlock(base_filters, base_filters * 2)   # Output: (64, 32, T/4)
        self.layer3 = ConvBlock(base_filters * 2, base_filters * 4) # Output: (128, 16, T/8)
        self.layer4 = ConvBlock(base_filters * 4, base_filters * 8) # Output: (256, 8, T/16)
        
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.dropout = nn.Dropout(dropout)
        self.fc = nn.Linear(base_filters * 8, num_classes)

    def forward(self, x):
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        
        x = self.gap(x)
        x = x.view(x.size(0), -1)
        x = self.dropout(x)
        x = self.fc(x)
        return x
