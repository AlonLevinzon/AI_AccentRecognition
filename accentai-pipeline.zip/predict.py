import torch
import yaml
import os
import argparse
import torch.nn.functional as F
from src.preprocessing.audio import AudioPreprocessor
from src.models.cnn import AccentClassifier
from src.utils.reproducibility import get_device

class Predictor:
    def __init__(self, checkpoint_path, labels_path, config_path):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
            
        with open(labels_path, 'r') as f:
            self.labels = yaml.safe_load(f)
            
        self.device = get_device()
        self.preprocessor = AudioPreprocessor(self.config)
        
        num_classes = len(self.labels)
        self.model = AccentClassifier(num_classes, self.config)
        
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.model.to(self.device)
        self.model.eval()

    def predict(self, audio_path):
        waveform = self.preprocessor.load_audio(audio_path)
        waveform = self.preprocessor.preprocess(waveform)
        features = self.preprocessor.extract_features(waveform).unsqueeze(0) # add batch dim
        
        features = features.to(self.device)
        with torch.no_grad():
            outputs = self.model(features)
            probabilities = F.softmax(outputs, dim=1)
            confidence, predicted_idx = torch.max(probabilities, 1)
            
        label = self.labels[predicted_idx.item()]
        return label, confidence.item()

def main():
    parser = argparse.ArgumentParser(description="Accent AI Prediction Script")
    parser.add_argument("--input", type=str, required=True, help="Path to wav/mp3 file or directory")
    parser.add_argument("--checkpoint", type=str, default="checkpoints/best_model.pth")
    parser.add_argument("--labels", type=str, default="outputs/labels.yaml")
    parser.add_argument("--config", type=str, default="configs/config.yaml")
    
    args = parser.parse_args()
    
    predictor = Predictor(args.checkpoint, args.labels, args.config)
    
    if os.path.isfile(args.input):
        label, conf = predictor.predict(args.input)
        print(f"File: {args.input} | Prediction: {label} | Confidence: {conf:.4f}")
    elif os.path.isdir(args.input):
        print(f"Scanning directory: {args.input}")
        for file in os.listdir(args.input):
            if file.endswith(('.wav', '.mp3')):
                path = os.path.join(args.input, file)
                label, conf = predictor.predict(path)
                print(f"File: {file} | Prediction: {label} | Confidence: {conf:.4f}")
    else:
        print("Error: Input path not found.")

if __name__ == "__main__":
    main()
